export const educationData = [
    {
        id: 1,
        institution: 'Texas Tech University',
        course: 'Master\'s in Computer Science ',
        startYear: '2022',
        endYear: '2024'
    },
    {
        id: 2,
        institution: 'R.V.R & J.C College of Engineering',
        course: 'Bachelor of Technology',
        startYear: '2015',
        endYear: '2019'
    },
    
]