export const contactsData = {
    email: 'vadderavikiran@gmail.com',
    phone: '+1 (806) 702-2270',
    address: 'Salt Lake City, UT, United States - 84116 ',

    sheetAPI: ''
}