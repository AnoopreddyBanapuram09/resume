export const socialsData = {
    github: 'https://github.com/ravikiranvadde',
    facebook: 'https://www.facebook.com/bunty.ravi.50',
    linkedIn: 'https://www.linkedin.com/in/vadderavikiran/',
    instagram: 'https://www.instagram.com/',
    codepen: 'https://codepen.io/',
    twitter: 'https://twitter.com/',
    reddit: 'https://www.reddit.com/user/',
    blogger: 'https://www.blogger.com/',
    medium: 'https://medium.com/@',
    stackOverflow: 'https://stackoverflow.com/users/',
    gitlab: 'https://gitlab.com/',
    youtube: 'https://youtube.com/'
}